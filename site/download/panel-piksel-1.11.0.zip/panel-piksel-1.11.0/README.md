# Panel & Piksel 1.11.0

Retro-pikselowy design system dla katalogów, list ofert, tabel, rankingów i sklepów: białe panele z czarną ramką 2 px
i twardym cieniem, gęste numerowane listy, czytelne Archivo, piksel (Press Start 2P, ikony 12×12) tam, gdzie się patrzy,
a nie czyta. Paleta SNES (Jehkoba32) z akcentami NES, tryb jasny, ciemny i wysokiego kontrastu.

Właściciel systemu: Konrad Kosiorek. Źródło prawdy: `design.md`.

## Co jest w paczce

| Katalog / plik | Do czego |
|---|---|
| `design.md` | Pełna specyfikacja: zarządzanie (§0), zasady, tokeny, komponenty i wzorce (§6), treści (§6A), dostępność (§8), kod (§9), historia zmian (§12) |
| `panel-piksel/` | Kod systemu — kopiujesz do projektu bez zmian |
| `panel-piksel/tokens.css`, `components.css`, `icons.css` | Style (tokeny, komponenty, ikony) |
| `panel-piksel/list-controls.js`, `table-sort.js`, `ui-controls.js`, `charts.js` | Zachowanie: listy i filtry, sortowanie tabel, formularze i nakładki, wykresy — bez zależności |
| `panel-piksel/tokens.json` | Tokeny w formacie W3C Design Tokens (Tokens Studio dla Figmy, Style Dictionary) |
| `panel-piksel/components.json` | Rejestr komponentów ze statusami (stabilny / testowy / wycofywany) |
| `panel-piksel/icons/` | Ikony jako pojedyncze pliki SVG |
| `panel-piksel/starter.html` | Szablon nowej strony |
| `examples/` | Działające przykłady: wszystkie komponenty i stany, wzorce, galeria ikon — otwórz w przeglądarce |
| `docs/panel-piksel-komponenty-v2.html` | Dokumentacja dla designerów: 29 kart rodzin (jeden plik, działa offline) |
| `skill/panel-piksel-ui/` | Skill dla Claude Code: agent buduje ekrany z tych klocków i sprawdza je skryptami |

## Szybki start (HTML)

```html
<link href="https://fonts.googleapis.com/css2?family=Archivo:ital,wght@0,400;0,600;0,700;0,800;0,900;1,400&family=Press+Start+2P&display=swap" rel="stylesheet">
<link rel="stylesheet" href="./panel-piksel/tokens.css">
<link rel="stylesheet" href="./panel-piksel/components.css">
<link rel="stylesheet" href="./panel-piksel/icons.css">
<!-- skrypty tylko gdy ekran ich potrzebuje -->
<script src="./panel-piksel/list-controls.js" defer></script>
<script src="./panel-piksel/table-sort.js" defer></script>
<script src="./panel-piksel/ui-controls.js" defer></script>
<script src="./panel-piksel/charts.js" defer></script>
```

Tryb ciemny: `<html data-theme="dark">` albo `data-theme="auto"` (wg ustawień systemu).
Zasady, których pilnujemy: ramka 2 px, tylko twarde cienie 2/4/6 px, jeden kolor akcji, jeden „głośny” element na ekran,
pixel-font tylko dla liczb i krótkich etykiet, stany nie zmieniają rozmiaru, wszystko co wygląda na klikalne — działa.

## Z agentem AI (Claude Code)

```bash
cp -r skill/panel-piksel-ui ~/.claude/skills/
```

Potem poproś np. „zbuduj ekran listy ofert w stylu Panel & Piksel”. Skill ma przepisy ekranów, kontrolę zasad
(`scripts/check_screen.py`), render w 1280/390 px z testem klikania (`scripts/render_check.py`), test wizualny
(`scripts/visual_regression.py`) i synchronizację kopii (`scripts/sync_system.py`).

## Wersje i zmiany

Semver w `VERSION`: poprawka (1.11.x) · nowy element lub wycofanie (1.x) · usunięcie wycofanego elementu (x.0).
Wycofane elementy działają do następnej wersji głównej, a `check_screen.py` podaje zamiennik. Nowe komponenty zgłaszaj
według `design.md` §0.5 — decyduje właściciel systemu.

## Licencja

Do ustalenia przez właściciela systemu. Fonty: Archivo i Press Start 2P — SIL Open Font License (Google Fonts).
